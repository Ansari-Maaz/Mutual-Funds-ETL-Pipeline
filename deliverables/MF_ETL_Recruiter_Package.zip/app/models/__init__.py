"""Canonical SQLAlchemy models."""
