"""Validated canonical data contracts."""
