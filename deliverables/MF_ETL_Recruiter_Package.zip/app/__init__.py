"""Global mutual fund ETL."""
